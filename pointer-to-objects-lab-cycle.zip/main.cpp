//pointer to objects
#include <iostream>
using namespace std;
class item 
{
    int code;
    public:
    void get()
    {
        cout<<"enter code";
        cin>>code;
    }
    void show()
    {
        cout<<"code"<<code<<"\n";
    }
};
int main()
{
   item X;
   item *ptr = new item[5];
   X.get();
   X.show();
   cout<<"Array of pointer objects"<<endl;
   for(int i=0;i<5;i++)
   {
       ptr->get();
       ptr->show();
   }
    return 0;
}

